﻿using Microsoft.EntityFrameworkCore;
using Xideral.Site.Shared.Modelos;

namespace Xideral.API.Context
{
    public class ConexionSQLServer : DbContext
    {
        public ConexionSQLServer(DbContextOptions<ConexionSQLServer> dbContextOptions):base(dbContextOptions)
        {
                

        }

        public DbSet<Usuarios> Usuarios { get; set; }
        public DbSet<Tareas> Tareas { get; set; }

    }
}
