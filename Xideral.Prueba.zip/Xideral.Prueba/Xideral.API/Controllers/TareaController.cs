﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Xideral.API.Context;
using Xideral.Site.Shared;
using Xideral.Site.Shared.Modelos;

namespace Xideral.API.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class TareaController : ControllerBase
    {
        private readonly ILogger<TareaController> _logger;
        private readonly ConexionSQLServer _context;
        public TareaController(ILogger<TareaController> logger, ConexionSQLServer context)
        {
            _logger = logger;
            _context = context;
        }

        [HttpGet(Name = "Tarea")]
        public DataResponse List(int idUsuario)
        {
            try
            {
                return new DataResponse()
                {
                    DataValue = JsonConvert.SerializeObject(_context.Tareas.Where(c => c.Usuario_ID == idUsuario).ToList()),
                    ErrorMessage = "OK"
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new DataResponse() { DataValue = "", ErrorMessage = ex.Message };
            }
        }

        [HttpPost(Name = "Tarea")]
        public DataResponse Nueva(TareaDTO _tarea)
        {
            try
            {
                Tareas tarea = new Tareas()
                {
                    Tarea_Titulo = _tarea.Titulo,
                    Tarea_Descripcion = _tarea.Descripcion,
                    Tarea_Fecha_Vencimiento =  _tarea.FechaVencimiento,
                    Usuario_ID = _tarea.IdUsuario
                };

                if (_context.Usuarios.FirstOrDefault(c => c.Usuario_Alias.ToLower() == tarea.Tarea_Titulo.ToLower()) != null)
                    return new DataResponse() { DataValue = "", ErrorMessage = "Ya existe la tarea." };

                _context.Add(tarea);
                _context.SaveChanges();

                return new DataResponse() { DataValue = JsonConvert.SerializeObject(_context.Tareas.FirstOrDefault(c => c.Tarea_Titulo == tarea.Tarea_Titulo)), ErrorMessage = "OK" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new DataResponse() { DataValue = "", ErrorMessage = ex.Message };
            }
        }
        [HttpPut(Name = "Tarea")]
        public DataResponse Editar(TareaDTO _tarea)
        {
            try
            {
                Tareas tarea = _context.Tareas.FirstOrDefault(c => c.Tarea_ID == _tarea.IdTarea);

                tarea.Tarea_Titulo = _tarea.Titulo;
                tarea.Tarea_Descripcion = _tarea.Descripcion;
                tarea.Tarea_Fecha_Vencimiento = _tarea.FechaVencimiento;

                _context.Tareas.Update(tarea);
                _context.SaveChanges();

                return new DataResponse() { DataValue = JsonConvert.SerializeObject(_context.Tareas.FirstOrDefault(c => c.Tarea_Titulo == tarea.Tarea_Titulo)), ErrorMessage = "OK" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new DataResponse() { DataValue = "", ErrorMessage = ex.Message };
            }
        }

        [HttpDelete(Name = "Tarea")]
        public DataResponse Eliminar(TareaDTO _tarea)
        {
            try
            {
                Tareas tarea = _context.Tareas.FirstOrDefault(c => c.Tarea_ID == _tarea.IdTarea);

                _context.Remove(tarea);
                _context.SaveChanges();

                return new DataResponse() { DataValue = JsonConvert.SerializeObject(_context.Tareas.FirstOrDefault(c => c.Tarea_Titulo == tarea.Tarea_Titulo)), ErrorMessage = "OK" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new DataResponse() { DataValue = "", ErrorMessage = ex.Message };
            }
        }
    }
}
