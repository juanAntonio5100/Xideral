﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Xideral.API.Context;
using Xideral.Site.Shared;
using Xideral.Site.Shared.Modelos;

namespace Xideral.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UsuarioController : ControllerBase
    {
        private readonly ILogger<UsuarioController> _logger;
        private readonly ConexionSQLServer _context;
        private readonly IConfiguration _configuration;

        public UsuarioController(ILogger<UsuarioController> logger, ConexionSQLServer context, IConfiguration configuration)
        {
            _logger = logger;
            _context = context;
            _configuration = configuration;
        }


        [HttpPost]
        [Route("LoginDetails")]
        public async Task<IActionResult> LoginDetails(LoginDTO _userData)
        {
            try
            {
                if (_userData != null)
                {
                    var resultLoginCheck = _context.Usuarios
                        .Where(e => e.Usuario_Alias == _userData.Alias && e.Usuario_Password == _userData.Clave)
                        .FirstOrDefault();
                    if (resultLoginCheck == null)
                    {
                        return BadRequest("Invalid Credentials");
                    }
                    else
                    {
                        _userData.Mensaje = "Login Success";

                        var claims = new[] {
                        new Claim(JwtRegisteredClaimNames.Sub, _configuration["Jwt:Subject"]),
                        new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                        new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                        new Claim("Alias", _userData.Alias.ToString()),
                        new Claim("Clave", _userData.Clave)
                        //new Claim("Rol", _userData.Rol)
                        };

                        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]));
                        var signIn = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
                        var token = new JwtSecurityToken(
                            _configuration["Jwt:Issuer"],
                            _configuration["Jwt:Audience"],
                            claims,
                            expires: DateTime.UtcNow.AddMinutes(5),
                            signingCredentials: signIn);

                        _userData.AccessToken = new JwtSecurityTokenHandler().WriteToken(token);
                        _userData.Rol = resultLoginCheck.Usuario_Rol;
                        _userData.IdUsuario = resultLoginCheck.Usuario_ID.ToString();
                    }
                }
                else
                {
                    return BadRequest("No Data Posted");
                }
            }
            catch (Exception ex)
            {

            }
            return Ok(_userData);
        }

        [HttpGet(Name = "Usuario")]
        public DataResponse ListUsuarios()
        {
            try
            {
                return new DataResponse() { DataValue = JsonConvert.SerializeObject(_context.Usuarios.ToList()),
                    ErrorMessage = "OK" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new DataResponse() { DataValue = "", ErrorMessage = ex.Message };
            }
        }

        [HttpPost(Name = "Usuario")]
        public DataResponse Usuario(UsuarioDTO _usuario)
        {
            try
            {
                Usuarios usuario  = new Usuarios()
                {
                 Usuario_Alias = _usuario.ClaveUsuario,
                  Usuario_Password = _usuario.Password,
                   Usuario_Rol = _usuario.Rol
                };

                if (_context.Usuarios.FirstOrDefault(c => c.Usuario_Alias.ToLower() == usuario.Usuario_Alias.ToLower())!= null)
                    return new DataResponse() { DataValue = "", ErrorMessage = "Ya existe el usuario." };

                _context.Add(usuario);
                _context.SaveChanges();

                return new DataResponse() { DataValue = JsonConvert.SerializeObject(_context.Usuarios.FirstOrDefault(c => c.Usuario_Alias == usuario.Usuario_Alias)), ErrorMessage = "OK" };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message);
                return new DataResponse() { DataValue = "", ErrorMessage = ex.Message };
            }
        }       
    }
}
