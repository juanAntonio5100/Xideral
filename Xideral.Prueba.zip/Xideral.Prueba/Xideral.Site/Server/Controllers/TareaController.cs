﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using Xideral.Site.Client.Pages;
using Xideral.Site.Shared;
using Xideral.Site.Shared.Modelos;
using static Xideral.Site.Server.Controllers.TareaController;

namespace Xideral.Site.Server.Controllers

{
    [Route("api/[controller]")]
    [ApiController]
    public class TareaController : ControllerBase
    {
        [HttpPost]
        [Route("List")]
        public async Task<IActionResult> List(TareasUsuario tareasUsuario)
        {

            List<Tareas> tareas = new List<Tareas>();
            RestResponse response = new RestResponse();

            try
            {
                var options = new RestClientOptions("https://localhost:7173")
                {
                    Timeout = TimeSpan.FromMinutes(1),
                };
                var client = new RestClient(options);
                var request = new RestRequest("/api/Tarea/?idUsuario=" + tareasUsuario.idUsuario, Method.Get);
                request.AddHeader("Authorization", "Bearer " + tareasUsuario.accessToken);
                var body = @"";
                request.AddParameter("text/plain", body, ParameterType.RequestBody);

                response = await client.ExecuteAsync(request);

                if (response.StatusCode != System.Net.HttpStatusCode.Unauthorized)
                {
                    Console.WriteLine(response.Content);

                    string val = response.Content;
                    var parsed = JObject.Parse(val);


                    tareas = System.Text.Json.JsonSerializer.Deserialize<List<Tareas>>(parsed.SelectToken("dataValue").Value<string>().ToString());
                }
                else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    throw new Exception("Expiro el token de acceso.");
                }
            }
            catch (Exception ex)
            {
                if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    return StatusCode(StatusCodes.Status401Unauthorized, tareas);

                }
            }

            return StatusCode(StatusCodes.Status200OK, tareas);
        }

        [HttpPut]
        [Route("Registrar")]
        public async Task<IActionResult> Registrar([FromBody] TareaDTO tarea)
        {
            //Llamar el api de base de datos con postman
            RestResponse response = new RestResponse();
            try
            {
                var options = new RestClientOptions("https://localhost:7173")
                {
                    Timeout = TimeSpan.FromMinutes(1),
                };
                var client = new RestClient(options);
                var request = new RestRequest("/api/Tarea", Method.Post);
                request.AddHeader("Authorization", "Bearer " + tarea.accessToken);

                request.AddHeader("Content-Type", "application/json");

                var body = System.Text.Json.JsonSerializer.Serialize(tarea);


                request.AddStringBody(body, DataFormat.Json);
                response = await client.ExecuteAsync(request);


                if (response.StatusCode != System.Net.HttpStatusCode.Unauthorized)
                {
                    Console.WriteLine(response.Content);

                    string val = response.Content;
                    var parsed = JObject.Parse(val);

                }

                Console.WriteLine(response.Content);
            }
            catch (Exception ex)
            {
                if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    return StatusCode(StatusCodes.Status401Unauthorized, ex.Message);
                }
            }

            return StatusCode(StatusCodes.Status200OK, response.Content);
        }
        [HttpPut]
        [Route("Editar")]
        public async Task<IActionResult> Editar([FromBody] TareaDTO tarea)
        {
            //Llamar el api de base de datos con postman
            RestResponse response = new RestResponse();
            try
            {
                var options = new RestClientOptions("https://localhost:7173")
                {
                    Timeout = TimeSpan.FromMinutes(1),
                };
                var client = new RestClient(options);
                var request = new RestRequest("/api/Tarea", Method.Put);
                request.AddHeader("Authorization", "Bearer " + tarea.accessToken);

                request.AddHeader("Content-Type", "application/json");

                var body = System.Text.Json.JsonSerializer.Serialize(tarea);


                request.AddStringBody(body, DataFormat.Json);
                response = await client.ExecuteAsync(request);


                if (response.StatusCode != System.Net.HttpStatusCode.Unauthorized)
                {
                    Console.WriteLine(response.Content);

                    string val = response.Content;
                    var parsed = JObject.Parse(val);

                }

                Console.WriteLine(response.Content);
            }
            catch (Exception ex)
            {
                if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    return StatusCode(StatusCodes.Status401Unauthorized, ex.Message);
                }
            }

            return StatusCode(StatusCodes.Status200OK, response.Content);
        }
        
        [HttpPost]
        [Route("Eliminar")]
        public async Task<IActionResult> Eliminar(TareasUsuario tareasUsuario)
        {
            RestResponse response = new RestResponse();
            try
            {
                TareaDTO tareaDTO = new TareaDTO();
                tareaDTO.IdTarea = int.Parse(tareasUsuario.idTarea);
                  tareaDTO.Titulo= "string";
                tareaDTO.Descripcion= "string";
                tareaDTO.FechaVencimiento = DateTime.Parse("2024-06-19T01:15:29.293Z");
                tareaDTO.IdUsuario= 0;
                tareaDTO.accessToken= tareasUsuario.accessToken;

                var options = new RestClientOptions("https://localhost:7173")
                {
                    Timeout = TimeSpan.FromMinutes(1),
                };
                var client = new RestClient(options);
                var request = new RestRequest("/api/Tarea", Method.Delete);
                request.AddHeader("Content-Type", "application/json");
                request.AddHeader("Authorization", "Bearer " + tareasUsuario.accessToken);
                
                
                var body = System.Text.Json.JsonSerializer.Serialize(tareaDTO);

                request.AddStringBody(body, DataFormat.Json);
                 response = await client.ExecuteAsync(request);
                Console.WriteLine(response.Content);
            }
            catch (Exception ex)
            {
                StatusCode(StatusCodes.Status500InternalServerError, response.Content);
            }

            return StatusCode(StatusCodes.Status200OK, response.Content);
        }
        public class TareasUsuario
        {
            public string idUsuario { get; set; }
            public string idTarea { get; set; }

            public string accessToken { get; set; }
        }



    }
}
