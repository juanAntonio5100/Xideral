﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System.Text.Json;
using System.Text.Json.Serialization;
using Xideral.Site.Client.Pages;
using Xideral.Site.Shared;
using Xideral.Site.Shared.Modelos;

namespace Xideral.Site.Server.Controllers

{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuarioController : ControllerBase
    {
        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login([FromBody] LoginDTO login)
        {
            SesionDTO sesionDTO = new SesionDTO();
            //Llamar el api de base de datos con postman
            var options = new RestClientOptions("https://localhost:7173")
            {
                Timeout = TimeSpan.FromMinutes(1),
            };
            var client = new RestClient(options);
            var request = new RestRequest("/api/Usuario/LoginDetails", Method.Post);
            request.AddHeader("Content-Type", "application/json");

            var body = System.Text.Json.JsonSerializer.Serialize(login);

            request.AddStringBody(body, DataFormat.Json);

            RestResponse response = await client.ExecuteAsync(request);

            Console.WriteLine(response.Content);

            LoginDTO sesionDTOTemp = JsonConvert.DeserializeObject<LoginDTO>(response.Content);

            sesionDTO.Alias = sesionDTOTemp.Alias;
            sesionDTO.Clave = sesionDTOTemp.Clave;
            sesionDTO.Rol = sesionDTOTemp.Rol;
            sesionDTO.Token = sesionDTOTemp.AccessToken;
            sesionDTO.IdUsuario = sesionDTOTemp.IdUsuario;


            return StatusCode(StatusCodes.Status200OK, sesionDTO);
        }

        [HttpGet]
        [Route("List")]
        public async Task<IActionResult> List()
        {
            List<Usuarios> usuarios = new List<Usuarios>();
           
            try
            {
                var client = new HttpClient();
                var request = new HttpRequestMessage(HttpMethod.Get, "https://localhost:7173/api/Usuario");
                var response = await client.SendAsync(request);
                response.EnsureSuccessStatusCode();

                string val = await response.Content.ReadAsStringAsync();
                var parsed = JObject.Parse(val);


                usuarios = System.Text.Json.JsonSerializer.Deserialize<List<Usuarios>>(parsed.SelectToken("dataValue").Value<string>().ToString());

                Console.WriteLine();
            }
            catch (Exception ex)
            {
            }

            return StatusCode(StatusCodes.Status200OK, usuarios);
        }

        [HttpPut]
        [Route("Registrar")]
        public async Task<IActionResult> Registrar([FromBody] UsuarioDTO usuario)
        {
            //Llamar el api de base de datos con postman
            RestResponse response = new RestResponse();
            try
            {
                var options = new RestClientOptions("https://localhost:7173")
                {
                    Timeout = TimeSpan.FromMinutes(1),
                };
                var client = new RestClient(options);
                var request = new RestRequest("/api/Usuario", Method.Post);
                request.AddHeader("Content-Type", "application/json");

                var body = System.Text.Json.JsonSerializer.Serialize(usuario);


                request.AddStringBody(body, DataFormat.Json);
                response = await client.ExecuteAsync(request);
                Console.WriteLine(response.Content);
            }
            catch (Exception ex)
            {
                StatusCode(StatusCodes.Status500InternalServerError, response.Content);
            }

            return StatusCode(StatusCodes.Status200OK, response.Content);
        }

    }
}
