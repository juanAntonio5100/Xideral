﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xideral.Site.Shared
{
    public class DataResponse
    {
        public string ErrorMessage { get; set; }
        public string DataValue { get; set; }

    }
}
