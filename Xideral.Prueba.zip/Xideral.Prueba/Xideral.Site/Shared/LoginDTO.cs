﻿using System.ComponentModel.DataAnnotations;

namespace Xideral.Site.Shared
{
    public class LoginDTO
    {

        public string Alias { get; set; }

        public string Clave { get; set; }
        public string Rol { get; set; }
        public string Mensaje { get; set; }
        public string AccessToken { get; set; }
        public string IdUsuario { get; set; }


    }
}
