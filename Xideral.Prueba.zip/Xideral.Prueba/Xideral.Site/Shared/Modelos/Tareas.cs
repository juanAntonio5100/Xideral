﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Xideral.Site.Shared.Modelos
{
    public class Tareas
    {
        [Key]
        public int Tarea_ID { get; set; }
        public string Tarea_Titulo { get; set; }
        public string Tarea_Descripcion { get; set; }
        public DateTime Tarea_Fecha_Vencimiento { get; set; }
        
        public int Usuario_ID { get; set; }
    }
}
