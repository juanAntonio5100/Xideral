﻿using System.ComponentModel.DataAnnotations;

namespace Xideral.Site.Shared.Modelos
{
    public class Usuarios
    {
        [Key]
        public int Usuario_ID { get; set; }
        public string Usuario_Alias { get; set; }
        public string Usuario_Password { get; set; }
        public string Usuario_Rol { get; set; }

    }
}
