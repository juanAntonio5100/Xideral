﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xideral.Site.Shared
{
    public class TareaDTO
    {
        public int IdTarea { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido.")]
        public string Titulo { get; set; } = null!;

        [Required(ErrorMessage = "El campo {0} es requerido.")]
        public string Descripcion { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido.")]
        public DateTime FechaVencimiento { get; set; }
        public int IdUsuario { get; set; }
        public string accessToken { get; set; }



    }
}
