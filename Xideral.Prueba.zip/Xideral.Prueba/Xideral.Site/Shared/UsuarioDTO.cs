﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Xideral.Site.Shared
{
    public class UsuarioDTO
    {
        public int IdUsuario { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido.")]
        public string ClaveUsuario { get; set; } = null!;

        [Required(ErrorMessage = "El campo {0} es requerido.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "El campo {0} es requerido.")]
        public string Rol { get; set; }      

    }
}
